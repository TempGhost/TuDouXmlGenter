﻿using System;
using System.Data;
using System.Web;
using System.Collections;
using System.Net;
using System.Net.Cache;
using System.IO;
using System.Net.NetworkInformation;
using System.Configuration;
using System.Text;
using System.Threading;
using System.Collections;
using System.Linq;
using System.Xml;

public partial class GetXml : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request["vUrl"] != null)
        {
            try
            {
                //       TuDouVdoStuff(Request["Vurl"].ToString());
                // string[] TestUrl = {"FuzVlmWQV0w",
                //"xw4e5_KkwDc",
                //"04SkWmv4olY",
                //"PDrav1qgGN8",
                //"Z9W-A0g_rkE",
                //"K_xyiOWYPOI",
                //"bYpfXO0kowk",
                //"qBSJF0Ctu28",
                //"exX2SXx_G08",
                //"CnNQrXCDlgE",
                //"p5n1Hx1y2hc",
                //"2VphVZdIAW0",
                //"lDQc4GI7Rrw",
                //"_m-ypUBCnpQ",
                //"kiIQvUvr6T8",
                //"ZcMZk4H4MD4",
                //"poRbNRhPyvg",
                //"AV9rQSH5OOA",
                //"u3YpU-BmgEk",
                //"FVxZfAdKZjg",
                //"fBIlS01Xyhk",
                //"a2H_8YHfkZw",
                //"c4KtesHp5e8",
                //"qezoS_amI9s",
                //"6whbmPU68Is",
                //"I8gc-kgmFc8",
                //"LjkBnTHKjh4",
                //"S3F4GUzJlIs",
                //"e1oytxxXffg",
                //"PgwvQv2f11o",
                //"DHXopX9uemk",
                //"ZlF12anvPvI",
                //"TAfqkPppb7k",
                //"jJFw913mRpc",
                //"KLakby7sqVc",
                //"fb3xGpYguJY",
                //"x3l4UEs-zU0",
                //"jMoKgwaV2Os",
                //"1PcIbR4tdV4",
                //"ON7FTvLMag8",
                //"TiNzBXMg8vM",
                //"j7-iGW3cixA",
                //"RlNt_B1STis",
                //"K6ff17E4gDg",
                //"EvcQNySu_ZI",
                //"XRXL-rA3Wic",
                //"LTbHt0LRVlU",
                //"bYzGI1_F6N0",
                //"FuzVlmWQV0w",
                //"xw4e5_KkwDc",
                //"Z9W-A0g_rkE",
                //"K_xyiOWYPOI",
                //"exX2SXx_G08",
                //"CnNQrXCDlgE",
                //"lDQc4GI7Rrw",
                //"_m-ypUBCnpQ",
                //"poRbNRhPyvg",
                //"AV9rQSH5OOA",
                //"u3YpU-BmgEk",
                //"c4KtesHp5e8",
                //"qezoS_amI9s",
                //"6whbmPU68Is",
                //"I8gc-kgmFc8",
                //"LjkBnTHKjh4",
                //"S3F4GUzJlIs",
                //"KLakby7sqVc",
                //"fb3xGpYguJY",
                //"x3l4UEs-zU0",
                //"TiNzBXMg8vM",
                //"j7-iGW3cixA",
                //"EvcQNySu_ZI",
                //"XRXL-rA3Wic"
                //};


                string context="";
            //for (int i = 0; i <TestUrl.Length ; i++)
            //  {
            //      context+= TuDouVdoStuff("http://www.tudou.com/programs/view/" + TestUrl[i]);
            //  }
            
            context = TuDouVdoStuff(Request["vUrl"].ToString()); //程序入口
            
            Response.ContentType = "text/xml";
            Response.Clear();
            Response.Write(context.ToString());
            Response.End();

        }
            catch (Exception)
        {
           throw;
            Response.Write("参数不正确");
        }

    }
        else
        {
            Response.Clear();
            Response.Write("禁止访问");
          //  Response.Close();
        }
    }
    /// <summary>
    /// 获取土豆网视频的主程序
    /// </summary>
    /// <param name="Url">传入的土豆网地址</param>
    /// <returns></returns>
    public  string   TuDouVdoStuff(string Url){
        string HD = "";
        if (Request["HD"] != null)//获取传入的hd参数来过去指定清晰度的视频地址
        {
            HD = Request["HD"].ToString();
        }
        string result = "";
        Response.Clear();
        string Context = GetTuDouData(Url);//获取响应报文中的配置参数集合 格式为json集合
        string[] BaseUrl = FormatingTuDouDate(Context, ref result, "\"baseUrl\"").Replace("}", "").Replace("]", "").Split(',');//获取报文中JASON集合中的Baseurl参数的集合
        result = ""; //主要上面方法使用的递归 这个变量要清空一下
        string[] KArray = FormatingTuDouDate(Context, ref result, "\"k\"").Replace("}", "").Replace("]", "").Split(',');//同上
        result = "";//同上
        string[] SizeArray = FormatingTuDouDate(Context, ref result, "\"size\"").Replace("}", "").Replace("]", "").Replace("'", "").Split(',');//同上
        result = "";//同上
        string[] SecondsArray = FormatingTuDouDate(Context, ref result, "\"seconds\"").Replace("}", "").Replace("]", "").Replace("'", "").Split(',');//同上
        result = "";//同上
        string[] NoArray = FormatingTuDouDate(Context, ref result, "\"no\"").Replace("}", "").Replace("]", "").Replace("'", "").Split(',');//同上
        result = "";//同上
        string[] PtArray = FormatingTuDouDate(Context, ref result, "\"pt\"").Replace("}", "").Replace("]", "").Replace("'", "").Split(',');//同上
        
        for (int i = 0; i < SecondsArray.Length; i++)//由于土豆中配置的每段视频的长度是毫秒 而ckplayer中需要的是秒 这里有一个转换 四舍五入法
        {
            SecondsArray[i] = ToInt(SecondsArray[i]).ToString();
        }
        
        string[][] ArrayStuff = { BaseUrl, SecondsArray, NoArray, PtArray, KArray, SizeArray }; //构造二维数组
        
        //TuDouVdo[] IDonTCare = GernerateTuDouVdoList(ArrayStuff);
        result = GernerateXml(GernerateTuDouVdoList(ArrayStuff));//生成xml  
        return result;
        //Response.Close();
    }
    /// <summary>
    ///将二维数组转换为TuDouVdo对象集合
    /// </summary>
    /// <param name="VdoVar"></param>
    /// <returns>TuDouVdo集合</returns>
    public TuDouVdo[] GernerateTuDouVdoList(string [][] VdoVar)
    {
        TuDouVdo[] Result = new TuDouVdo[VdoVar[0].Length];
        for (int i = 0; i < VdoVar[0].Length; i++)
        {
            Result[i] = new TuDouVdo(VdoVar[0][i].ToString(), VdoVar[1][i].ToString(), VdoVar[2][i].ToString(), VdoVar[3][i].ToString(),VdoVar[4][i].ToString(), VdoVar[5][i].ToString());
        }
        return Result ; 
    }

    /// <summary>
    /// 生成xml
    /// </summary>
    /// <param name="ArrayStuff">二维数组</param>
    /// <returns>xml格式文本</returns>
    public string GernerateXml(string[][] ArrayStuff)
    {
        string result = "<?xml version=\"1.0\" encoding=\"utf-8\"?><ckplayer>";
        for (int i = 0; i < ArrayStuff[0].Count(); i++)
        {
            result += "<video>";
            result += "<file><![CDATA[http://vr.tudou.com/v2proxy/v?sid=11000&id=" + ArrayStuff[0][i].ToString() + "&st=2]]></file>";//地址段
            result += " <size>" + ArrayStuff[1][i].ToString() + "</size>";//视频大小 单位是字节
            result += " <seconds>" + ArrayStuff[2][i].ToString() + "</seconds>";//视频长度 /秒
            result += "</video>";
        }
        result += "</ckplayer>";
        return result;
    }

    /// <summary>
    /// 生成xml
    /// </summary>
    /// <param name="ArrayStuff">tudouvdo对象集合</param>
    /// <param name="pt"></param>
    /// <returns> xml格式文本</returns>
    public string GernerateXml(TuDouVdo[] ArrayStuff, string pt = "")
    {
        if (pt=="")
        {
            pt = ArrayStuff[0].Pt;
        }
        string result= "<?xml version=\"1.0\" encoding=\"utf-8\"?><ckplayer>";
        for (int i = 0; i < ArrayStuff.Count(); i++)
        {
            if (ArrayStuff[i].Pt==pt)
            {
                result += "<video>";
                result += "<file><![CDATA[http://vr.tudou.com/v2proxy/v?sid=11000&id=" + ArrayStuff[i].K.ToString() + "&st=2]]></file>";
                result += " <size>" + ArrayStuff[i].Size.ToString() + "</size>";
                result += " <seconds>" + ArrayStuff[i].Seconds.ToString() + "</seconds>";
                result += "</video>";
            }
        }
        result += "</ckplayer>";
        return result;
    }
    /// <summary>
    /// 将指定的参数从报文中提取出来（递归）
    /// </summary>
    /// <param name="date">请求报文</param>
    /// <param name="result">递归遗传变量</param>
    /// <param name="KeyName">参数名</param>
    /// <returns></returns>
    public string FormatingTuDouDate(string date, ref string result, string KeyName = "\"baseUrl\"")
    {

        string key = KeyName;
        if (date.IndexOf(key)>-1)//递归出口
        {
            int StratIndex = date.IndexOf(key) + key.Length;//获得起始下标
            int EndIndex;
            if (date.IndexOf(",", StratIndex) > -1)//以逗号结尾的情况
            {
                EndIndex = date.IndexOf(",", StratIndex);//获得结束下标
            }
            else if (date.IndexOf("}") > -1)//以花括弧结尾的情况
            {
                EndIndex = date.IndexOf(",", StratIndex);//获得结束下标
            }
            else { EndIndex = -1; }
            if (StratIndex>=0&&EndIndex>=0)//有效性验证
            {
                int Lenght = EndIndex - StratIndex;//计算长度
                result = result!=""?result + ","+ date.Substring(StratIndex +1, Lenght - 1): date.Substring(StratIndex + 1, Lenght - 1);//三元运算符 截取出来的数据压入Result变量中
                date = date.Substring(EndIndex);
                if (date.IndexOf(KeyName) > -1)
                {
                    FormatingTuDouDate(date,ref result,KeyName); //递归，遗传截取到的数据到下一层 
                }
            }
        }
        return result.Replace("\r","").Replace("\n","").Replace("\t","");//去除换行符
    }
    /// <summary>
    /// 将整数转换为指定长度的整数四舍五入
    /// </summary>
    /// <param name="data">需要转换数据</param>
    /// <param name="legth">指定的长度</param>
    /// <returns></returns>
    public  static double  ToInt(string data)
    {
        return   Convert.ToInt32((Convert.ToDouble(data)/1000));
    }

    /// <summary>
    /// 将sessionid从请求到的报文中的js代码中抽离出来
    /// </summary>
    /// <returns> </returns>
    public static string GetParamFormJs(string Context, string SplitToken = ",", string ParamKey = "\"k\"")
    {

        string Result = "";
        string temp = Context;
        if (string.IsNullOrEmpty(temp))
        {
            return "";
        }
        if (temp.IndexOf(ParamKey) > -1)
        {
            int startIndex = temp.IndexOf(ParamKey) + ParamKey.Length + 1;

            if (temp.IndexOf("\"", startIndex) > 1)
            {
                int EndIndex = temp.IndexOf("\"", temp.IndexOf("\"", startIndex) + 1);
                Result = temp.Substring(startIndex + 1, EndIndex - startIndex - 1);
            }
        }

        return Result;
    }

    /// <summary>
    /// 程序入口
    /// </summary>
    /// <param name="Url"></param>
    /// <returns></returns>
    public string GetTuDouData(string Url)
    {
        string result= "";
        HttpWebRequest INRequest = (HttpWebRequest)WebRequest.Create(Url);
        string Accept="";
        foreach (string  item in Context.Request.AcceptTypes)
        {
            Accept = Accept == "" ? item : Accept + ',' + item;//构造请求头部
        }
        INRequest.Accept = Accept;
        INRequest.UserAgent = Context.Request.UserAgent;
        INRequest.Headers.Add(HttpRequestHeader.AcceptEncoding,Context.Request.Headers.Get(""));
        INRequest.Headers.Add(HttpRequestHeader.AcceptLanguage,Context.Request.Headers.Get("Accept-Encoding"));
        INRequest.Headers.Add(HttpRequestHeader.AcceptCharset, "utf-8");
    //    INRequest.Referer = Context.Request.UrlReferrer.ToString();
        result = HttpHelper.GetRequstData(INRequest);
        return result;         
    }


}